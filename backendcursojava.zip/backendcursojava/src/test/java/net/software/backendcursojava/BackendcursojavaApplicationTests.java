package net.software.backendcursojava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendcursojavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
